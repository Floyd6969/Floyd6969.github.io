# -*- coding: UTF-8 -*-
#######################################################################
 # ----------------------------------------------------------------------------
 # "THE BEER-WARE LICENSE" (Revision 42):
 # @tantrumdev wrote this file.  As long as you retain this notice you
 # can do whatever you want with this stuff. If we meet some day, and you think
 # this stuff is worth it, you can buy me a beer in return. - Muad'Dib
 # ----------------------------------------------------------------------------
#######################################################################

# Addon Name: Yoda
# Addon id: plugin.video.Yoda
# Addon Provider: Supremacy

import re,traceback,urllib,urlparse,base64
import requests

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import log_utils

class bnw(Scraper):
    domains = ['bnwmovies.com']
    name = "BNWmovies"
    sources = []


    def __init__(self):
        self.base_link = 'http://www.bnwmovies.com'
        self.search_link = "/search/%s"


    def scrape_movie(self, title, year, imdb, debrid=False):
        if int(year) > 1980:
            return self.sources
        try:
            start_time = time.time()
            query = urllib.quote_plus(clean_search(title.lower()))
            start_url = urlparse.urljoin(self.base_link, self.search_link % query)
            headers = {'User-Agent': client.agent(), 'Referer': self.base_link}
            count = 0
            html = client.request(start_url, headers=headers)
            posts = client.parseDOM(html, 'div',  attrs={'class': 'post'})
            posts = [(dom_parser.parse_dom(i, 'a', req='href')[0]) for i in posts if i]
            posts = [(i.attrs['href'], i.content) for i in posts if i]
            post = [(i[0]) for i in posts if clean_title(i[1]) == clean_title(title)][0]
            r = client.request(post, headers=headers)
            y = client.parseDOM(r, 'h1')[0]
            if not year in y:
                return self.sources
            links = client.parseDOM(r, 'source', ret='src')
            link = [i for i in links if i.endswith('mp4')][0]
            link += '|User-Agent=%s&Referer=%s' % (client.agent(), post)
            link = urllib.quote(link, ':/-_|&+=')
            count += 1
            self.sources.append({'source': 'bnw', 'quality': 'SD', 'scraper': self.name, 'url': link, 'direct': True})
            if dev_log == 'true':
                end_time = time.time() - start_time
                send_log(self.name,end_time,count,title,year)
            return self.sources
        except Exception, argument:
            if dev_log == 'true':
                error_log(self.name,argument)
            return self.sources
